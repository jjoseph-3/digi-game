extends Node2D

@export var wild_rat_spawn: PathFollow2D
@export var wild_rat_scene: PackedScene


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	Global.player_controllable.emit()


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _tall_grass_entered(body: Node2D) -> void:
	if body is Player:
		var spawn_chance: float = 0.8 
		if randf() < spawn_chance: #codes for an 80% encounter chance
			var wild_rat = wild_rat_scene.instantiate()
			wild_rat_spawn.progress_ratio = randf()
			wild_rat.global_position = wild_rat_spawn.global_position
			add_child(wild_rat) 
			#spawns the wild rats 


func _left_tall_grass(body: Node2D) -> void:
		if body is Player:
			for rat in get_tree().get_nodes_in_group("wild_rat"):
				rat.despawn()
				#despawns the wild rats when player leaves area
		
